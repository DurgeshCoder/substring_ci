<?= $this->extend('default') ?>


<!--pageTitle section start-->

<?= $this->section('pageTitle') ?>
Services | Substring Technologies
<?= $this->endSection() ?>
<!--pageTitle section end-->

<?= $this->section('content') ?>

<div class="container">
    <h1 class="text-3xl">This is services</h1>

</div>

<?= $this->include('home/banner') ?>

<?= $this->endSection() ?>
