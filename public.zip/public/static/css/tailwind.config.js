/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["../../../app/Views/**/*.{html,js,php}",],
    darkMode: 'class',
    theme: {
        extend: {},
    }, plugins: [],
}

